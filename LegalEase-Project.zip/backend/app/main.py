import os, io, json, re
from datetime import datetime
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from docx import Document
from reportlab.lib.pagesizes import LETTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from xml.sax.saxutils import escape

load_dotenv()
app = FastAPI(title="LegalEase API", version="1.0.0")
origin=os.getenv("FRONTEND_ORIGIN","http://localhost:5173")
app.add_middleware(CORSMiddleware, allow_origins=[origin], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class DraftRequest(BaseModel):
    document_type: str = Field(min_length=2, max_length=100)
    jurisdiction: str = Field(default="Not specified", max_length=150)
    parties: str = Field(min_length=2, max_length=4000)
    terms: str = Field(min_length=10, max_length=12000)
    tone: str = Field(default="Formal and clear", max_length=100)

class RefineRequest(BaseModel):
    content: str = Field(min_length=30, max_length=30000)
    instruction: str = Field(min_length=3, max_length=2000)

class ExportRequest(BaseModel):
    title: str = "LegalEase Draft"
    content: str = Field(min_length=1, max_length=30000)

def fallback_draft(r):
    return f"""DRAFT — FOR REVIEW BY A QUALIFIED LEGAL PROFESSIONAL

{r.document_type.upper()}

Jurisdiction: {r.jurisdiction}

PARTIES
{r.parties}

RECITALS AND PURPOSE
The parties intend to set out their understanding in this document. The following draft is based solely on the information supplied by the user.

TERMS AND CONDITIONS
{r.terms}

GENERAL PROVISIONS
1. Applicable law and jurisdiction: To be confirmed by a qualified legal professional for the stated jurisdiction.
2. Amendments: Any changes should be recorded in writing and accepted by all relevant parties.
3. Entire understanding: The parties should confirm that this document accurately records their complete understanding.
4. Severability: The effect of any invalid provision should be reviewed under applicable law.

SIGNATURES

Party 1: __________________________  Date: ______________

Party 2: __________________________  Date: ______________

IMPORTANT: This is an AI-assisted draft, not legal advice. It may omit mandatory clauses, statutory requirements, or jurisdiction-specific formalities. Obtain legal review before signing or relying on it.
"""

def gemini_generate(prompt):
    key=os.getenv("GEMINI_API_KEY")
    if not key or key=="your_google_ai_studio_api_key":
        return None
    try:
        from google import genai
        client=genai.Client(api_key=key)
        response=client.models.generate_content(model=os.getenv("GEMINI_MODEL","gemini-2.5-flash"), contents=prompt)
        return response.text
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Gemini request failed: {str(e)}")

@app.get("/api/health")
def health():
    return {"status":"ok","service":"LegalEase API","gemini_configured":bool(os.getenv("GEMINI_API_KEY") and os.getenv("GEMINI_API_KEY")!="your_google_ai_studio_api_key")}

@app.get("/api/document-types")
def document_types():
    return {"document_types":["Rental / Lease Agreement","Employment Agreement","Non-Disclosure Agreement (NDA)","Demand / Legal Notice","Service Agreement","Affidavit (draft)","General Agreement"]}

@app.post("/api/generate")
def generate(r: DraftRequest):
    prompt=f"""You are a careful legal document drafting assistant. Create a structured, readable first draft of the requested document using ONLY the supplied facts. Do not invent names, dates, amounts, statutes, legal citations, or facts. If essential details are missing, insert clearly labeled [REQUIRES INPUT] placeholders. Use neutral, formal language. State that the draft needs review by a qualified lawyer and that laws vary by jurisdiction. Do not claim the document is legally enforceable.

Document type: {r.document_type}
Jurisdiction: {r.jurisdiction}
Parties: {r.parties}
Terms and facts: {r.terms}
Tone: {r.tone}
Return the document text only, with useful headings and signature blocks where appropriate."""
    result=gemini_generate(prompt)
    return {"content":result or fallback_draft(r),"provider":"Gemini" if result else "Local fallback","created_at":datetime.utcnow().isoformat()+"Z"}

@app.post("/api/refine")
def refine(r: RefineRequest):
    prompt=f"""Revise the following legal draft according to the user's instruction. Preserve all supplied facts, do not invent law or facts, mark missing information with [REQUIRES INPUT], and retain a legal-review disclaimer.
Instruction: {r.instruction}
Draft:
{r.content}
Return only the revised draft."""
    result=gemini_generate(prompt)
    if not result:
        return {"content":r.content+"\n\n[Local mode: Add a Gemini API key to enable AI refinement.]","provider":"Local fallback"}
    return {"content":result,"provider":"Gemini"}

@app.post("/api/export/docx")
def export_docx(r: ExportRequest):
    doc=Document()
    doc.add_heading(r.title,0)
    for para in r.content.splitlines():
        if para.strip():
            doc.add_paragraph(para)
        else:
            doc.add_paragraph("")
    buf=io.BytesIO(); doc.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", headers={"Content-Disposition":'attachment; filename="legalease-draft.docx"'})

@app.post("/api/export/pdf")
def export_pdf(r: ExportRequest):
    buf=io.BytesIO()
    pdf=SimpleDocTemplate(buf,pagesize=LETTER,title=r.title)
    styles=getSampleStyleSheet(); story=[Paragraph(escape(r.title),styles["Title"]),Spacer(1,12)]
    for para in r.content.splitlines():
        if para.strip(): story.append(Paragraph(escape(para),styles["BodyText"]))
        story.append(Spacer(1,6))
    pdf.build(story); buf.seek(0)
    return StreamingResponse(buf,media_type="application/pdf",headers={"Content-Disposition":'attachment; filename="legalease-draft.pdf"'})
