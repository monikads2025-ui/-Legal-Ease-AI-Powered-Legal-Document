# LegalEase — AI-Powered Legal Document Generator

A full-stack student project using React + Vite, FastAPI, and Google's Gemini API.

## Features
- Generate structured draft agreements and notices from user-provided information.
- Gemini integration through the backend (API key is never sent to the browser).
- Local fallback mode when no Gemini key is configured.
- Editable document preview, DOCX/PDF export, and browser-local history.
- Basic request validation and CORS configuration.

## Requirements
- Python 3.10+ (3.11 recommended)
- Node.js 20+ and npm
- Optional Google AI Studio API key for Gemini-powered generation: https://aistudio.google.com/apikey

## Setup in VS Code

Open the `LegalEase` folder in VS Code. Open two integrated terminals.

### 1. Backend
Windows PowerShell:
```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```
Edit `backend/.env` and set `GEMINI_API_KEY` to your key. You can leave the placeholder to test the local fallback. Do not commit `.env` or share your key.

Start API:
```powershell
uvicorn app.main:app --reload --port 8000
```
API docs: http://127.0.0.1:8000/docs
Health: http://127.0.0.1:8000/api/health

macOS/Linux activation: `source .venv/bin/activate`; copy env file with `cp .env.example .env`.

### 2. Frontend (second terminal)
```powershell
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite, normally http://localhost:5173.

## Test
1. Confirm `/api/health` returns `{"status":"ok",...}`.
2. Fill in document type, parties, and terms, then click Generate draft.
3. Edit the preview; export DOCX and PDF.
4. Open My documents to reopen or remove locally saved drafts.
5. For AI mode, verify health reports `gemini_configured: true`; if generation errors, check the API key, model access, network, and backend terminal.

## API endpoints
- `GET /api/health`
- `GET /api/document-types`
- `POST /api/generate`
- `POST /api/refine`
- `POST /api/export/docx`
- `POST /api/export/pdf`

## Important legal and privacy notes
This is an educational drafting tool, not legal advice. AI-generated content can be inaccurate, incomplete, or unsuitable for a jurisdiction. A qualified lawyer should review all drafts before use. Do not enter unnecessary sensitive personal information. History is stored in browser localStorage; clearing browser data removes it. This starter does not implement user accounts, server-side persistence, encryption-at-rest, or production authentication.
